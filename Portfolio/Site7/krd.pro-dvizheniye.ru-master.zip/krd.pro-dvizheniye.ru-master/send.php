<script language='Javascript'><!-- 
function reload() {location = "spasibo.html"}; setTimeout('reload()', 0); 
//--></script> 
 
 hello world
 
 
<p></p>